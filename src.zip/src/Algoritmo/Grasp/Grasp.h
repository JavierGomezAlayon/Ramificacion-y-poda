// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: DAA
// Curso: 3º
// Práctica 06 : Ramificación_y_poda
// Autor: javier Gómez Alayón
// Correo: alu0101562445@ull.edu.es
// Fecha: 04/25/25
// Archivo Grasp.h : Declaración de la clase Grasp
//        En este fichero se declara la clase Grasp
//
// Historial de revisiones
//        04/25/25 - Creación (primera versión) del código
#ifndef C_Grasp_H
#define C_Grasp_H
#include "../Algoritmo.h"

class Grasp : public Algoritmo {
 public:
  Grasp();
  Grasp* solve() override;
  Grasp* setTamLista(int tam_lista); 
 private:
  Punto puntoMasLejano(Punto centro);
  int tam_lista_;
};

#endif