// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: DAA
// Curso: 3º
// Práctica 06 : Ramificación_y_poda
// Autor: javier Gómez Alayón
// Correo: alu0101562445@ull.edu.es
// Fecha: 04/25/25
// Archivo BusquedaLocal.h : Declaración de la clase BusquedaLocal
//        En este fichero se declara la clase BusquedaLocal
//
// Historial de revisiones
//        04/25/25 - Creación (primera versión) del código
#ifndef C_BusquedaLocal_H
#define C_BusquedaLocal_H
#include "../Algoritmo.h"

class BusquedaLocal : public Algoritmo {
 public:
  BusquedaLocal();
  BusquedaLocal* solve() override;
  BusquedaLocal* setSolucion(EspacioVectorial& solucion);
 private:
   
 
};

#endif